package calculatorVersion2;

import java.util.ArrayList;
import java.util.List;

public class Calculator {


    private List<Double> result = new ArrayList<>();

    public double calculate(int num1, int num2, char cal) {
        if (cal == '+') {
            result.add((double) (num1 + num2));
            return num1 + num2;
        } else if (cal == '-') {
            result.add((double) (num1 - num2));
            return num1 - num2;
        } else if (cal == '*') {
            result.add((double) (num1 * num2));
            return num1 * num2;
        } else if (cal == '/') {
            if (num2 == 0) {
                System.out.println("0으로 나눌 수 없습니다");
            } else {
                result.add((double) (num1 / num2));
                return num1 / num2;
            }
        } else {
            System.out.println("값을 잘 못 입력하셨습니다.");
        }
        return 0.0;
    }

    public List<Double> getResult() {
        return result;
    }
    public void setResult(Double result){
        this.result.add(result);
    }
    public void zeroIndexDeleteList() {
        result.remove(0);
    }
}